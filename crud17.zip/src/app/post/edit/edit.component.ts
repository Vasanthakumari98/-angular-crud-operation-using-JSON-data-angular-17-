import { PostService } from './../post.service';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Post } from '../post';
import { Router, RouterModule } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './edit.component.html',
  styleUrl: './edit.component.scss'
})
export class EditComponent {
id!:number;
post!:Post;
form!:FormGroup;

constructor(public PostService:PostService, private router:Router,private route:ActivatedRoute){}
ngOnInit():void{
  this.id=this.route.snapshot.params['postId'];
  this.PostService.find(this.id).subscribe((data:Post)=>{
    this.post=data;
  });
  this.form=new FormGroup({
    title:new FormControl("",[Validators.required]),
    body:new FormControl("",Validators.required)
  });
}
get f(){
return this.form.controls;
}
submit(){
  console.log(this.form.value)
  this.PostService.update(this.id,this.form.value).subscribe((res:any)=>{
    alert("Data Updated Sucessfully 0")
    this.router.navigateByUrl('/post/index');
  })
}



}