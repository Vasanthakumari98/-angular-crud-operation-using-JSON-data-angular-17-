import { PostService } from './../post.service';
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Post } from '../post';

@Component({
  selector: 'app-index',
  standalone: true,
  imports: [CommonModule,RouterModule],
  templateUrl: './index.component.html',
  styleUrl: './index.component.scss'
})
export class IndexComponent {
  posts:Post[]=[];

  constructor(public PostService:PostService){}
ngOnInit():void{
this.PostService.getAll().subscribe((data:Post[])=>{
  this.posts=data;
  console.log(this.posts)
})
}
deletePost(id: number) {
  this.PostService.delete(id).subscribe(() => {
    this.posts = this.posts.filter(item => item.id !== id);
    alert("Post deleted successfully!!");
  });
}

  

}
