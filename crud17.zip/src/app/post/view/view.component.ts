import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Post } from '../post';
import { PostService } from '../post.service';

@Component({
  selector: 'app-view',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view.component.html',
  styleUrl: './view.component.scss'
})
export class ViewComponent {
id!:number;
post!:Post;


constructor(public postservice:PostService, private Router:Router,private route:ActivatedRoute){}
ngonit(){
this.id=this.route.snapshot.params['postId'];
this.postservice.find(this.id).subscribe((data:Post)=>{
this.post=data;
});
}

}
